package com.cognizant.library.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import com.cognizant.library.model.UserModel;

public class UserMapper implements RowMapper<UserModel>{
	
	public UserModel mapRow(ResultSet resultSet, int i) throws SQLException {
	UserModel user = new UserModel();
	user.setFirstname(resultSet.getString("user_firstname"));
	user.setLastname(resultSet.getString("user_lastname"));
	user.setDob(resultSet.getDate("user_dob"));
	user.setGender(resultSet.getString("user_gender"));
	
	user.setContactno(resultSet.getInt("user_contact"));
	user.setEmail(resultSet.getString("user_email"));
	user.setUserid(resultSet.getString("user_userid"));
	user.setPassword(resultSet.getString("user_password"));
	return user;
	}
}
