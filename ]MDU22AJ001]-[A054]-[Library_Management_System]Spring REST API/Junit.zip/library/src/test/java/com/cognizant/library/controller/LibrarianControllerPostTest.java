package com.cognizant.library.controller;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.text.SimpleDateFormat;
import java.util.Date;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import com.cognizant.library.LibraryApplication;
import com.cognizant.library.LibraryApplicationTests;
import com.cognizant.library.model.LibrarianModel;
import com.cognizant.library.service.LibrarianService;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest(classes = LibraryApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class LibrarianControllerPostTest extends LibraryApplicationTests {
	@Autowired
	private WebApplicationContext webApplicationContext;
	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}

	@MockBean
	private LibrarianService librarianService;

	@Test
	public void testPostUsers() throws Exception {
	}

	public void testPostUser() throws Exception {

		String sDate1 = "1234/12/12";
		Date d = new SimpleDateFormat("yyyy/MM/dd").parse(sDate1);
		LibrarianModel rm = new LibrarianModel("anuj", "axyz", d, "male", 45678, "xyz@yahoo", "xyz123", "anuj");

		Mockito.when(librarianService.postUser(Mockito.any(LibrarianModel.class))).thenReturn(true);

		mockMvc.perform(post("/updateLibrarian/{username}").content(asJsonString(rm))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON)).andDo(print())
				.andExpect(status().isCreated()).andExpect(content().contentType("application/json"));
	}
	
	@Test
	public void putUpdatePassword() throws Exception {



	LibrarianModel Registermodel = new LibrarianModel();
	Registermodel.setUsername("Admin");
	Registermodel.setPassword("adminxyz");
	Mockito.when(librarianService.checkLogin(Mockito.any(LibrarianModel.class))).thenReturn(true);
	mockMvc.perform(put("/librarianlogin").content(asJsonString(Registermodel)).contentType(MediaType.APPLICATION_JSON)
	.accept(MediaType.APPLICATION_JSON)).andDo(print()).andExpect(status().isOk());
	}

	public static String asJsonString(final Object obj) {
		try {
			return new ObjectMapper().writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}

	}

}